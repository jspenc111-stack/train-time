# START HERE (instructions for Claude Code)

The owner uploaded `leave-by-files.zip` to this repo. It holds the whole project. Do this:

1. Unzip `leave-by-files.zip` into the repo root. It already has the right folders and overwrites the starter README. Then delete the zip and this START_HERE.md.
2. Read `CLAUDE.md`, then follow it from now on (public repo, no personal details, tests first, PRs).
3. In `apps-script/Code.gs`, set `DEFAULTS.appUrl` to `https://<repo-owner>.github.io/<repo-name>/`, using this repo's owner and name.
   - Nothing else changes, so `VERSION` stays as it is.
4. Run `node tests/run.js`. All 26 tests must pass.
5. Commit on a branch, push, and open a pull request.
   - Title: "Add Leave By app".
   - Fill in the PR template in plain English.
6. Tell the owner, in plain language:
   - **Before merging:** turn on GitHub Pages. In the repo, go to **Settings → Pages → Source: GitHub Actions**.
   - **Then:** merge the PR (in the GitHub app: open the PR → Merge). After about 2 minutes the app is live at the Pages link.
   - Give the exact link.
   - **After that:** follow `README.md` → "One-time setup".

Do not change app behavior. If something must change, update SPEC.md too and explain why.
